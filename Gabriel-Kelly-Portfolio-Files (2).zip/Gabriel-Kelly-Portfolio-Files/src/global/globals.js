export const appTitle = "Premium Gabe";

export const apiPath = "https://premiumgabe.com/portfolio/wp-json/wp/v2"
export const apiPath_projects = `${apiPath}/fwd-project/?_embed&acf_format=standard`
export const apiPath_pages = `${apiPath}/pages/52/?_embed`